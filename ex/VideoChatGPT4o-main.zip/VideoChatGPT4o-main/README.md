# VideoChatGPT4o
Discuss in video and audio with ChatGPT4o
Allow you to record a small video from you browser and webcam and submit audio and video to ChatGPT4o for analyse.
The reply is spoken using Text To Speech of OpenAI

Need to have an API key (paid)

# Installation
pip install shiny 
brew install FFmpeg
brew install openai-whisper
brew install python-openai
pipx install openai        
pip install python-datauri
pip install git+https://github.com/jcheng5/shinymedia

# IDE setup
Use VSCodium or VSCode, then install Shiny extention

# Thanks
This has bring to you based on an idea of Joe Cheng @Posit
