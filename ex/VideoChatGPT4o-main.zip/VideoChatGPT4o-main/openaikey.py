import openai
import os
os.environ["OPENAI_API_KEY"] = "xxxxxxxxxxxxxxxx"
